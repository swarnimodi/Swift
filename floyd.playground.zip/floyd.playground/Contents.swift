import UIKit

func floyd(_ n : Int)
{
    var x = 1
    print("Floyd's triangle for \(n): ")
    for i in 1 ... n
    {
        for _ in 1 ... i
        {
            print(x, terminator:" ")
            x += 1
        }
        print()
    }
}

floyd(7)
