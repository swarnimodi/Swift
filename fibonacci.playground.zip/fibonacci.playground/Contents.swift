import UIKit

func fibo(_ n : Int)
{
    var x = 0
    var y = 1
    print("Fibonacci series uptil \(n)th term:")
    
    for _ in 1 ... n
    {
        print(x, terminator:" ")
        let z = x + y
        x = y
        y = z
    }
}

fibo(15)
